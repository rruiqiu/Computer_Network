gcc -o app main.c call_arrival.c call_departure.c call_duration.c cleanup.c output.c simlib.c
