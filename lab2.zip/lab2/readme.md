gcc -o app main.c simlib.c output.c packet_arrival.c cleanup_memory.c packet_transmission.c
